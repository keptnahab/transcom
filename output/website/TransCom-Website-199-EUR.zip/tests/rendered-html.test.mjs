import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("https://beta.transcom.test/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("renders the TransCom product and pricing page", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /TransCom \| Lokale Live-Transkription für macOS/);
  assert.match(html, /Hören\. Verstehen\./);
  assert.match(html, /Audio bleibt lokal/);
  assert.match(html, /Deutsch \+ Englisch/);
  assert.match(html, /Nicht für sicherheitskritische Produktion/);
  assert.match(html, /Starter kostenlos nutzen/);
  assert.match(html, /295 €/);
  assert.match(html, /Neue Transkripte bis 1 Minute je Session/);
  assert.match(html, /Persönlich freischalten/);
  assert.match(html, /Noch kein Online-Checkout/);
  assert.match(html, /og-v2\.png/);
  assert.match(html, /TransCom_Beta-Handbuch_DE\.pdf/);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape|react-loading-skeleton/i);
});

test("ships the product social card and keeps the handbook", async () => {
  const packageJson = await readFile(new URL("package.json", root), "utf8");
  assert.doesNotMatch(packageJson, /react-loading-skeleton/);
  await access(new URL("public/og-v2.png", root));
  await access(new URL("public/downloads/TransCom_Beta-Handbuch_DE.pdf", root));
  await assert.rejects(access(new URL("app/_sites-preview/SkeletonPreview.tsx", root)));
  await assert.rejects(access(new URL("public/favicon.svg", root)));
});
