const transcriptLines = [
  { time: "00:12", speaker: "REGIE", color: "blue", text: "Wir gehen in dreißig Sekunden live." },
  { time: "00:16", speaker: "STAGE", color: "orange", text: "Copy. Kamera zwei ist bereit." },
  { time: "00:21", speaker: "AUDIO", color: "green", text: "The host microphone is open." },
  { time: "00:27", speaker: "REGIE", color: "blue", text: "Danke. Stand by … und los." },
];

const feedbackHref =
  "data:text/plain;charset=utf-8," +
  encodeURIComponent(`TransCom Beta – Feedback\n\nKurzfazit\nWürdest du die App für einen weiteren Test verwenden? Ja / Nein / Nur mit Einschränkungen\nWarum?\n\nSchwere Probleme\nWas hat den Test oder die Bedienung blockiert?\n\nAudio\nWar der Demo-Ton hörbar?\nWelche Audioquelle wurde verwendet?\n\nTranskript\nBeste erkannte Stelle:\nSchlechteste erkannte Stelle:\nBeispiel Original / erwartet / erkannt:\n\nLatenz\nGut / akzeptabel / zu langsam / nicht verwendbar\nNotizen:\n\nUX\nWas war unklar?\nWelche Buttons oder Begriffe waren missverständlich?\n\nSonstiges\n`);

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="TransCom Startseite">
          <span className="brand-mark" aria-hidden="true"><i /><i /><i /><i /></span>
          <span>TransCom</span>
        </a>
        <nav aria-label="Hauptnavigation">
          <a href="#produkt">Produkt</a>
          <a href="#editionen">Editionen</a>
          <a href="#faq">FAQ</a>
          <a href="#hinweise">Hinweise</a>
        </nav>
        <a className="button button-small button-dark" href="#editionen">Editionen vergleichen</a>
      </header>

      <section className="hero" id="top">
        <div className="alpine-profile" aria-hidden="true">
          <i className="alpine-ridge alpine-ridge-1" />
          <i className="alpine-ridge alpine-ridge-2" />
          <i className="alpine-ridge alpine-ridge-3" />
          <i className="alpine-ridge alpine-ridge-4" />
        </div>
        <div className="hero-copy">
          <div className="eyebrow"><span className="status-dot" /> Beta · macOS Apple Silicon</div>
          <h1>Hören. Verstehen. <em>Lokal.</em></h1>
          <p className="hero-lead">
            TransCom macht gemischte Intercom- und Produktions-Audiofeeds auf deinem Mac lesbar – live oder aus einer Datei, auf Deutsch und Englisch.
          </p>
          <div className="hero-actions">
            <a className="button button-primary" href="#editionen">Starter kostenlos nutzen <span aria-hidden="true">→</span></a>
            <a className="button button-quiet" href="#produkt">So funktioniert es</a>
          </div>
          <ul className="trust-list" aria-label="Kernmerkmale">
            <li><span>✓</span> Audio bleibt lokal</li>
            <li><span>✓</span> Deutsch + Englisch</li>
            <li><span>✓</span> Ohne Cloud-API</li>
          </ul>
        </div>

        <div className="hero-visual" aria-label="Vorschau der TransCom Bedienoberfläche">
          <div className="app-window">
            <div className="window-bar">
              <div className="traffic"><span /><span /><span /></div>
              <strong>TransCom <b>BETA</b></strong>
              <span className="live-pill"><i /> LIVE</span>
            </div>
            <div className="app-body">
              <aside className="app-sidebar">
                <span className="mini-label">SESSION</span>
                <strong>Generalprobe</strong>
                <div className="sidebar-rule" />
                <span className="mini-label">AUDIO FEED</span>
                <div className="source-card active-source"><i /> Live Input</div>
                <div className="source-card"><i /> Audio File</div>
                <div className="level-bars" aria-hidden="true">
                  {[14, 27, 19, 36, 48, 32, 22, 41, 53, 29, 17, 34, 45, 24].map((height, index) => <i key={index} style={{ height }} />)}
                </div>
                <div className="language-row"><span>Sprache</span><strong>DE + EN</strong></div>
              </aside>
              <section className="transcript-preview">
                <div className="transcript-head">
                  <div><span className="mini-label">LIVE TRANSCRIPT</span><strong>Generalprobe</strong></div>
                  <span className="recording"><i /> Aufzeichnung läuft</span>
                </div>
                <div className="transcript-list">
                  {transcriptLines.map((line, index) => (
                    <div className={`transcript-line line-${index + 1}`} key={line.time}>
                      <time>{line.time}</time>
                      <span className={`speaker speaker-${line.color}`}>{line.speaker}</span>
                      <p>{line.text}</p>
                    </div>
                  ))}
                </div>
                <div className="listening"><span /><span /><span /><span /><b>TransCom hört zu …</b></div>
              </section>
            </div>
          </div>
          <div className="local-card"><span className="shield" aria-hidden="true">✓</span><div><strong>Lokale Verarbeitung</strong><small>Dein Audio verlässt den Mac nicht.</small></div></div>
        </div>
      </section>

      <section className="facts-band" aria-label="Produktüberblick">
        <div><strong>2</strong><span>Sprachen<br />Deutsch & Englisch</span></div>
        <div><strong>1</strong><span>gemischter<br />Audiofeed</span></div>
        <div><strong>0</strong><span>Cloud-APIs<br />im Kernbetrieb</span></div>
        <div><strong>TXT<br /><small>CSV</small></strong><span>lokaler Export<br />in Full</span></div>
      </section>

      <section className="section intro-section" id="warum">
        <div className="section-heading">
          <span className="kicker">FÜR PRODUKTIONSTEAMS</span>
          <h2>Ein zweites Paar Ohren<br />für den <em>Live-Moment.</em></h2>
        </div>
        <p>Intercom-Kommunikation ist schnell, dicht und flüchtig. TransCom macht aus einem gemischten Feed ein lesbares, lokal gespeichertes Arbeitsprotokoll – ohne den Anspruch, die Regie zu ersetzen.</p>
      </section>

      <section className="feature-grid" id="produkt">
        <article className="feature feature-dark">
          <span className="feature-number">01</span>
          <div className="feature-icon waveform-icon" aria-hidden="true"><i /><i /><i /><i /><i /></div>
          <h3>Live oder Datei</h3>
          <p>Nutze ein Audiointerface, ein virtuelles Loopback-Gerät oder spiele WAV, AIFF, MP3 und M4A zum Testen in Echtzeit ein.</p>
          <span className="feature-tag">Ein gemischter Summenfeed</span>
        </article>
        <article className="feature">
          <span className="feature-number">02</span>
          <div className="feature-icon language-icon" aria-hidden="true">DE <small>/</small> EN</div>
          <h3>Zweisprachig gedacht</h3>
          <p>Der Beta-Launcher arbeitet im Automatikmodus für gemischte deutsche und englische Kommunikation.</p>
          <span className="feature-tag">Andere Sprachen sind nicht Ziel der Beta</span>
        </article>
        <article className="feature feature-warm">
          <span className="feature-number">03</span>
          <div className="feature-icon local-icon" aria-hidden="true"><span>⌁</span></div>
          <h3>Lokal gespeichert</h3>
          <p>Audio wird lokal verarbeitet. Sessions und Transkripte bleiben auf dem Mac; Full schaltet den Export als TXT und CSV frei.</p>
          <span className="feature-tag">Offline-first</span>
        </article>
      </section>

      <section className="pricing section" id="editionen">
        <div className="pricing-heading">
          <div>
            <span className="kicker">ZWEI EDITIONEN</span>
            <h2>Kostenlos anfangen.<br /><em>Bei Bedarf freischalten.</em></h2>
          </div>
          <p>Starter hält dein Archiv zugänglich und lässt dich TransCom mit kurzen neuen Sessions erproben. Full hebt das Zeitlimit auf und schaltet den Export frei.</p>
        </div>

        <div className="price-grid">
          <article className="price-card starter-card">
            <div className="price-card-top"><span>STARTER</span><b>KOSTENLOS</b></div>
            <h3>0 €</h3>
            <p className="price-subline">Kein Kauf erforderlich</p>
            <ul>
              <li><span>✓</span> Vorhandene Transkripte ansehen</li>
              <li><span>✓</span> Vorhandene Transkripte bearbeiten und verwalten</li>
              <li><span>✓</span> Neue Transkripte bis 1 Minute je Session</li>
              <li className="not-included"><span>–</span> Kein Export</li>
            </ul>
            <span className="button price-disabled" aria-disabled="true">App-Download folgt</span>
            <small>Der Download wird erst nach finaler Freigabe aktiviert.</small>
          </article>

          <article className="price-card full-card">
            <div className="recommended">VOLLE FUNKTION</div>
            <div className="price-card-top"><span>FULL</span><b>EINMALIG</b></div>
            <h3>199 €</h3>
            <p className="price-subline">Einmalige Freischaltung</p>
            <ul>
              <li><span>✓</span> Alles aus Starter</li>
              <li><span>✓</span> Neue Transkripte ohne 1-Minuten-Grenze</li>
              <li><span>✓</span> Export als TXT und CSV</li>
              <li><span>✓</span> Lokale Verarbeitung und Speicherung</li>
            </ul>
            <a className="button button-primary" href="#paket-uebergabe">Persönlich freischalten <span aria-hidden="true">→</span></a>
            <small>Der direkte Kauflink folgt. Noch kein Online-Checkout.</small>
          </article>
        </div>

        <p className="pricing-note"><strong>Beta-Hinweis:</strong> Beide Editionen befinden sich weiterhin in der Beta. Sie sind nicht für sicherheitskritische Produktion freigegeben.</p>
      </section>

      <section className="workflow section" id="ablauf">
        <div className="section-heading narrow">
          <span className="kicker">DER BETA-TEST</span>
          <h2>In drei Schritten<br />zum ersten <em>Transkript.</em></h2>
        </div>
        <div className="steps">
          <article><span>1</span><div><h3>Paket entpacken</h3><p>TransCom ist ein nicht signierter macOS-arm64-Build. Die App per Rechtsklick öffnen und beim ersten Start kurz laden lassen.</p></div></article>
          <article><span>2</span><div><h3>Demo-Feed starten</h3><p>„Audio File“ wählen, die mitgelieferte Demo-WAV laden und „Start Feed“ klicken.</p></div></article>
          <article><span>3</span><div><h3>Beobachten & berichten</h3><p>Transkriptqualität, Latenz und Bedienfluss testen. Gute wie schlechte Beispiele helfen.</p></div></article>
        </div>
      </section>

      <section className="beta-kit" id="beta-start">
        <div className="kit-copy">
          <span className="kicker light">PRODUKT & HANDBUCH</span>
          <h2>Gut vorbereitet<br />in den ersten Test.</h2>
          <p>Die begleitete Beta enthält den macOS-arm64-App-Build, Installationsanleitung, Handbuch, Datenschutz- und Beta-Hinweise sowie Test- und Feedbackvorlagen.</p>
          <div className="kit-actions">
            <a className="button button-primary" href="#editionen">Edition wählen <span aria-hidden="true">→</span></a>
            <a className="button button-outline-light" href="/downloads/TransCom_Beta-Handbuch_DE.pdf">Handbuch als PDF</a>
          </div>
          <small>Private Beta · Version 0.2.0-beta.1 · Nicht für sicherheitskritische Produktion</small>
        </div>
        <div className="package-card" aria-label="Inhalt des Beta-Pakets">
          <div className="package-top"><span>TRANSCOM</span><b>BETA</b></div>
          <div className="package-art"><div className="disc"><i /><i /><i /><i /></div></div>
          <strong>Beta-Testpaket</strong>
          <p>macOS · Apple Silicon</p>
          <ul><li>App-Build</li><li>Dokumentation</li><li>Testprotokoll</li></ul>
        </div>
      </section>

      <section className="faq section" id="faq">
        <div className="faq-heading">
          <span className="kicker">FRAGEN & ANTWORTEN</span>
          <h2>Was vor dem Start<br /><em>wichtig ist.</em></h2>
        </div>
        <div className="faq-list">
          <details open>
            <summary>Bleiben Audio und Transkripte wirklich lokal?<span>+</span></summary>
            <p>Ja. Der Kernbetrieb ist offline-first: Audio wird lokal verarbeitet, Sessions und Transkripte werden lokal auf dem Mac gespeichert. Ein optionaler Viewer läuft nur im lokalen Netzwerk.</p>
          </details>
          <details>
            <summary>Was kann Starter kostenlos?<span>+</span></summary>
            <p>Du kannst alle vorhandenen Transkripte ansehen, bearbeiten und verwalten. Für neue Transkripte gilt eine Grenze von einer Minute je Session; Export ist nicht enthalten.</p>
          </details>
          <details>
            <summary>Was ändert sich mit Full?<span>+</span></summary>
            <p>Full entfernt die 1-Minuten-Grenze für neue Transkripte und schaltet den Export als TXT und CSV frei. Die Freischaltung kostet einmalig 199 €.</p>
          </details>
          <details>
            <summary>Kann ich Full schon online kaufen?<span>+</span></summary>
            <p>Noch nicht. Bis der direkte Checkout freigegeben ist, wird Full persönlich freigeschaltet. Auf dieser Seite gibt es bewusst keinen provisorischen oder simulierten Kaufprozess.</p>
          </details>
          <details>
            <summary>Ist TransCom für kritische Live-Produktion freigegeben?<span>+</span></summary>
            <p>Nein. TransCom ist weiterhin Beta-Software. Erkennungsqualität, Latenz und Bedienfluss werden weiter verbessert; die App ist nicht für sicherheitskritische Produktion freigegeben.</p>
          </details>
        </div>
      </section>

      <section className="resources section" id="handbuch">
        <div>
          <span className="kicker">BEGLEITUNG</span>
          <h2>Beim Test nicht<br />allein gelassen.</h2>
        </div>
        <div className="resource-list">
          <a href="/downloads/TransCom_Beta-Handbuch_DE.pdf"><span className="resource-icon">01</span><div><strong>Beta-Handbuch als PDF</strong><small>20 Seiten: Installation, erster Test und Fehlerhilfe</small></div><b>↓</b></a>
          <a href="#hinweise"><span className="resource-icon">02</span><div><strong>Beta- & Datenschutzhinweise</strong><small>Was die Beta kann – und was noch nicht</small></div><b>→</b></a>
          <a href={feedbackHref} download="TransCom_Beta_Feedback.txt"><span className="resource-icon">03</span><div><strong>Feedbackvorlage</strong><small>Strukturiertes Feedback lokal ausfüllen</small></div><b>↓</b></a>
        </div>
      </section>

      <section className="limitations section" id="hinweise">
        <div className="limitations-copy">
          <span className="kicker">EHRLICHE BETA</span>
          <h2>Für Tests gebaut.<br /><em>Noch nicht für den Ernstfall.</em></h2>
          <p>TransCom befindet sich in Stabilisierung und Qualitätsverbesserung. Die Beta soll zeigen, was unter realistischen Bedingungen schon funktioniert – und wo nachgebessert werden muss.</p>
        </div>
        <ul>
          <li><span>!</span><div><strong>Erkennungsqualität</strong><p>Die ASR-Qualität liegt noch unter dem angestrebten Niveau.</p></div></li>
          <li><span>!</span><div><strong>Live-Gefühl</strong><p>Die erste nutzbare Ausgabe kann noch zu langsam wirken.</p></div></li>
          <li><span>!</span><div><strong>Bedienfluss</strong><p>Session- und Feed-Ablauf werden mit der Beta weiter geschärft.</p></div></li>
          <li><span>!</span><div><strong>Keine Produktionsfreigabe</strong><p>Nicht für sicherheitskritische oder produktive Multi-User-Umgebungen.</p></div></li>
        </ul>
      </section>

      <section className="handoff section" id="paket-uebergabe">
        <div>
          <span className="eyebrow"><span className="status-dot" /> Rollout in Vorbereitung</span>
          <h2>Starter oder Full –<br />dein Einstieg steht.</h2>
          <p>Der öffentliche App-Download und der direkte Full-Checkout werden nach finaler technischer und rechtlicher Freigabe aktiviert. Bis dahin bleibt die Produktseite privat und Full wird persönlich freigeschaltet.</p>
        </div>
        <div className="handoff-actions">
          <a className="button button-primary" href="#editionen">Editionen vergleichen <span aria-hidden="true">↑</span></a>
          <a className="text-link" href={feedbackHref} download="TransCom_Beta_Feedback.txt">Feedbackvorlage laden ↓</a>
          <a className="text-link" href="#top">Noch einmal von oben ↑</a>
        </div>
      </section>

      <footer>
        <a className="brand brand-light" href="#top"><span className="brand-mark" aria-hidden="true"><i /><i /><i /><i /></span><span>TransCom</span></a>
        <p>Lokale Live-Transkription für macOS · Starter & Full · Beta</p>
        <span>© 2026 TransCom</span>
      </footer>
    </main>
  );
}
