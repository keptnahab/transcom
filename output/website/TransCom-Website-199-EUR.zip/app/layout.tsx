import type { Metadata } from "next";
import { headers } from "next/headers";
import Script from "next/script";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const incoming = await headers();
  const host = incoming.get("x-forwarded-host") ?? incoming.get("host") ?? "localhost:3000";
  const protocol = incoming.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;
  const title = "TransCom | Lokale Live-Transkription für macOS";
  const description = "TransCom macht gemischte Intercom- und Produktions-Audiofeeds lokal auf dem Mac lesbar. Starter kostenlos, Full einmalig 199 €.";

  return {
    metadataBase: new URL(origin),
    title,
    description,
    openGraph: {
      title: "TransCom | Hören. Verstehen. Lokal.",
      description: "Lokale deutsch-englische Live-Transkription auf Apple Silicon – Starter kostenlos, Full ohne Zeitlimit und mit Export.",
      type: "website",
      url: origin,
      images: [{ url: `${origin}/og-v2.png`, width: 1536, height: 1024, alt: "TransCom – Hören. Verstehen. Lokal. Starter und Full." }],
    },
    twitter: {
      card: "summary_large_image",
      title: "TransCom | Hören. Verstehen. Lokal.",
      description: "Lokale deutsch-englische Live-Transkription auf Apple Silicon – Starter kostenlos, Full ohne Zeitlimit und mit Export.",
      images: [`${origin}/og-v2.png`],
    },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="de">
      <body>
        {children}
        <Script id="statcounter-config" strategy="afterInteractive">
          {`var sc_project=13336359; var sc_invisible=1; var sc_security="0ec70585";`}
        </Script>
        <Script
          id="statcounter"
          src="https://www.statcounter.com/counter/counter.js"
          strategy="afterInteractive"
        />
        <noscript>
          <div className="statcounter">
            <a title="Web Analytics Made Easy - Statcounter" href="https://statcounter.com/" target="_blank" rel="noreferrer">
              <img className="statcounter" src="https://c.statcounter.com/13336359/0/0ec70585/1/" alt="Web Analytics Made Easy - Statcounter" referrerPolicy="no-referrer-when-downgrade" />
            </a>
          </div>
        </noscript>
      </body>
    </html>
  );
}
